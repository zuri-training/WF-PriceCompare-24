from django.contrib import admin
#from .models import PriceCompare

# Register your models here.
#admin.site.register(PriceCompare)